//
//  File.swift
//  My App
//
//  Created by MillennialMovement on 2022-04-25.
//

import SwiftUI
import SpriteKit

struct WelcomeView: View {
    let normalColor = Color.init(red: 50/255.0, green: 50/255.0, blue: 50/255.0)
    let hoverColor = Color.init(red: 100/255.0, green: 100/255.0, blue: 100/255.0)
    @State var isTuErYeIntroductionViewHover = false
    @State var isCloisonneIntroductionViewHover = false
    @State var isSpriteTestHover = false
    
    var body: some View{
        NavigationView {
            VStack {
                NavigationLink(destination: TuErYeIntroductionView()) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(isTuErYeIntroductionViewHover ? hoverColor : normalColor)
                            .frame(width: .infinity, height: 150)
                            .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10))
                        HStack {
                            Image(systemName: "magazine.fill")
                                .tint(.white)
                            VStack {
                                Text("Introduction")
                                    .foregroundColor(.white)
                                    .font(.headline)
                                Text("Tu er Ye")
                                    .foregroundColor(.white)
                                    .font(.subheadline)
                            }
                        }
                    }
                }
                .onHover { isHover in
                    self.isTuErYeIntroductionViewHover = isHover
                }
                
                NavigationLink(destination: CloisonneIntroductionView()) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(isCloisonneIntroductionViewHover ? hoverColor : normalColor)
                            .frame(width: .infinity, height: 150)
                            .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10))
                        HStack {
                            Image(systemName: "magazine.fill")
                                .tint(.white)
                            VStack {
                                Text("Introduction")
                                    .foregroundColor(.white)
                                    .font(.headline)
                                Text("Cloisonne")
                                    .foregroundColor(.white)
                                    .font(.subheadline)
                                
                            }
                        }
                    }
                }
                .onHover { isHover in
                    self.isCloisonneIntroductionViewHover = isHover
                }
                
                NavigationLink(destination: SpriteTest()) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10) 
                            .fill(isSpriteTestHover ? hoverColor : normalColor)
                            .frame(width: .infinity, height: 150)
                            .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 10))
                        VStack {
                            HStack {
                                Image(systemName: "gamecontroller.fill")
                                    .tint(.white)     
                                VStack {
                                    Text("Try your self!")
                                        .foregroundColor(.white)
                                        .font(.headline)
                                }
                            }
                            HStack {
                                Spacer()
                                Text("When two intangible cultural heritages collide, what sparks will be produced? Let's try.")
                                    .foregroundColor(.white)
                                    .font(.caption)
                                Spacer()
                            }
                        }
                    }
                }
                .onHover { isHover in
                    self.isSpriteTestHover = isHover
                }
                
                Spacer()
            }
            .navigationTitle("Tu er Ye with Cloisonne")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct TuErYeIntroductionView: View {
    var body: some View{
        
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.init(red: 50/255.0, green: 50/255.0, blue: 50/255.0))
                .frame(width: .infinity, height: .infinity)
                .padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
            HStack {
                VStack(alignment: .center) {
                    Spacer()
                    Text("Tu er Ye")
                        .font(.system(size: 80))
                        .foregroundColor(.white)
                    HStack {
                        Spacer()
                        Text("    Tu er Ye is a local traditional handicraft in Beijing, and it is a children's toy for the Mid-Autumn Festival. Every Mid-Autumn Festival, the people in Beijing will worship 'Tu er Ye'. This custom originated in the Ming Dynasty.\n    According to the saying that there is a Chang'e Jade Rabbit in the Moon Palace, after the Jade Rabbit is further artistic, personified, and even deified, they are shaped into various forms of Rabbit Lord with mud. Since the Ming and Qing dynasties, the Moon Palace Jade Rabbit has gradually separated from the appendages of moon worship, and has formed an independent image in the ritual of worshiping the moon, and has gradually enriched it. Lord Rabbit has both sacred and secular qualities, and integrates the functions of sacrifice and entertainment. Today, Lord Rabbit has become one of the most representative Beijing intangible cultural heritages.")
                            .foregroundColor(.white)
                            .padding(60)
                        Spacer()
                    }

                    Spacer()
                }
            }
        }
    }
}

struct CloisonneIntroductionView: View {
    var body: some View{
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.init(red: 50/255.0, green: 50/255.0, blue: 50/255.0))
                .frame(width: .infinity, height: .infinity)
                .padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
            HStack {
                VStack(alignment: .center) {
                    Spacer()
                    Text("Cloisonne")
                        .font(.system(size: 80))
                        .foregroundColor(.white)
                    HStack {
                        Spacer()
                        Text("    Cloisonne, one of the famous special metal handicrafts in China, reached its peak during the Jingtai period of the Ming Dynasty, and the crafts produced were the most exquisite and famous, so later generations called this metalware 'Cloisonne'. Cloisonne is called 'copper tire cloisonné enamel', commonly known as 'enamel blue', also known as 'inlaid enamel'. An utensil made by filling the enamel color glaze into the pattern and firing it. Because it was popular in the Jingtai period of the Ming Dynasty, the production skills were relatively mature, and the enamel glaze used was mostly blue, so it was named 'cloisonne'")
                            .padding(60)
                            .foregroundColor(.white)
                        Spacer()
                    }
                    Spacer()
                }
            }
        }
    }
}
