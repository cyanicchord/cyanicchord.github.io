import SwiftUI
import SpriteKit

struct SpriteTest: View {
    
    var scene: SKScene {
        let scene = GameScene()
        scene.size = CGSize(width: Resolution.width, height: Resolution.height)
        scene.scaleMode = .aspectFill
        scene.anchorPoint = CGPoint(x: 0, y: 0)
        scene.backgroundColor = .systemGray6
        
        return scene
    }
    
    var body: some View {
        GeometryReader { geo in
            HStack {
                Spacer()
                VStack {
                    Spacer()
                    SpriteView(scene: scene)
                        .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
                        .ignoresSafeArea()
                }
                Spacer()
            }
        }
            
    }
}

struct ContentView: View {
    var body: some View {
        VStack {
            WelcomeView()
        }
    }
}

