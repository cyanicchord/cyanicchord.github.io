//
//  File.swift
//  My App
//
//  Created by MillennialMovement on 2022-04-24.
//
import SpriteKit

struct Resolution {
    static let width: CGFloat = 1000
    static let height: CGFloat = 1000
}
