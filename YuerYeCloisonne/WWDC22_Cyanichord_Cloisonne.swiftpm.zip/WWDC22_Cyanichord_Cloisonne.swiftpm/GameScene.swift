//
//  File.swift
//  My App
//
//  Created by MillennialMovement on 2022-04-24.
//

import SpriteKit
import SwiftUI
import GameplayKit
import Foundation

class GameScene: SKScene, SKPhysicsContactDelegate {
    var teyTotalContour: SKSpriteNode!
    var teyTigerWhite_pattern: SKSpriteNode!
    var teyTigerContour: SKSpriteNode!
    var teyEar_in: SKSpriteNode!
    var teyTigerBeard: SKSpriteNode!
    var teyTigerEyeball: SKSpriteNode!
    var teyTigerEyewhite: SKSpriteNode!
    var teyTigerNose: SKSpriteNode!
    var teyTigerMouth: SKSpriteNode!
    var teyTigerLips: SKSpriteNode!
    var teyTigerLeg: SKSpriteNode!
    var teyTigerEarOut: SKSpriteNode!
    var teyPad: SKSpriteNode!
    var teyShoeDown: SKSpriteNode!
    var teyShoe: SKSpriteNode!
    var teyPants: SKSpriteNode!
    var teyClothMid: SKSpriteNode!
    var teyClothUp: SKSpriteNode!
    var teyBeltPattern: SKSpriteNode!
    var teyBelt: SKSpriteNode!
    var teyLeftSleeve: SKSpriteNode!
    var teyHands: SKSpriteNode!
    var teyRightArmRing: SKSpriteNode!
    var teyRightArm: SKSpriteNode!
    var teyMouth: SKSpriteNode!
    var teyCheek: SKSpriteNode!
    var teyEyes: SKSpriteNode!
    var teyScarf: SKSpriteNode!
    var teyHatDown: SKSpriteNode!
    var teyHatJew: SKSpriteNode!
    var teyHatMid: SKSpriteNode!
    var teyHatUp: SKSpriteNode!
    var teyRightEarIn: SKSpriteNode!
    var teyRightEar: SKSpriteNode!
    var teyLeftEarIn: SKSpriteNode!
    var teyLeftEar: SKSpriteNode!
    var teyFace: SKSpriteNode!
    var basicNodes: [SKSpriteNode] = []
    var teyGold1: SKSpriteNode!
    var teyGold2: SKSpriteNode!
    var teyGold3: SKSpriteNode!
    var teyGold4: SKSpriteNode!
    var teyGold5: SKSpriteNode!
    var teyGold6: SKSpriteNode!
    var teyGold7: SKSpriteNode!
    var teyGold8: SKSpriteNode!
    var teyGold9: SKSpriteNode!
    var teyGold10: SKSpriteNode!
    var teyGold11: SKSpriteNode!
    var teyGold12: SKSpriteNode!
    var teyGold13: SKSpriteNode!
    var teyGold14: SKSpriteNode!
    var teyGold15: SKSpriteNode!
    var teyGold16: SKSpriteNode!
    var teyGold17: SKSpriteNode!
    var teyGold18: SKSpriteNode!
    var teyGold19: SKSpriteNode!
    var teyGold20: SKSpriteNode!
    var teyGold21: SKSpriteNode!
    var teyGold22: SKSpriteNode!
    var teyGold23: SKSpriteNode!
    var teyGold24: SKSpriteNode!
    var teyGold25: SKSpriteNode!
    var teyGold26: SKSpriteNode!
    var teyGold27: SKSpriteNode!
    var teyGold28: SKSpriteNode!
    var teyGold29: SKSpriteNode!
    var teyGold30: SKSpriteNode!
    var teyGold31: SKSpriteNode!
    var teyGold32: SKSpriteNode!
    var teyGold33: SKSpriteNode!
    var teyGold34: SKSpriteNode!
    var teyGold35: SKSpriteNode!
    var teyGold36: SKSpriteNode!
    var teyColor1: SKSpriteNode!
    var teyColor2: SKSpriteNode!
    var teyColor3: SKSpriteNode!
    var teyColor4: SKSpriteNode!
    var teyColor5: SKSpriteNode!
    var teyColor6: SKSpriteNode!
    var teyColor7: SKSpriteNode!
    var teyColor8: SKSpriteNode!
    var teyColor9: SKSpriteNode!
    var teyColor10: SKSpriteNode!
    var teyColor11: SKSpriteNode!
    var teyColor12: SKSpriteNode!
    var teyColor13: SKSpriteNode!
    var teyColor14: SKSpriteNode!
    var teyColor15: SKSpriteNode!
    var teyColor16: SKSpriteNode!
    var teyColor17: SKSpriteNode!
    var teyColor18: SKSpriteNode!
    var teyColor19: SKSpriteNode!
    var teyColor20: SKSpriteNode!
    var teyColor21: SKSpriteNode!
    var teyColor22: SKSpriteNode!
    var teyColor23: SKSpriteNode!
    var teyColor24: SKSpriteNode!
    var teyColor25: SKSpriteNode!
    var teyColor26: SKSpriteNode!
    var teyColor27: SKSpriteNode!
    var teyColor28: SKSpriteNode!
    var teyColor29: SKSpriteNode!
    var teyColor30: SKSpriteNode!
    var teyColor31: SKSpriteNode!
    var teyColor32: SKSpriteNode!
    var teyColor33: SKSpriteNode!
    var teyColor34: SKSpriteNode!
    var teyColor35: SKSpriteNode!
    var teyColor36: SKSpriteNode!
    var goldNodes: [SKSpriteNode] = []
    var colorNodes: [SKSpriteNode] = []
    var pad: SKShapeNode!
    
    var currentGold = 0
    var colorCount = 0
    var colorBegin = false
    var colorEnd = false
    
    override func didMove(to view: SKView) {
        setBlackNode()
        pad = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 300, height: 300), cornerRadius: 30)
        pad.fillColor = .black
        pad.zPosition = MaskLevel.minusOne.rawValue - 1
        pad.position = CGPoint(x: 110, y: 700)
        
        let text = SKLabelNode(text: "Option")
        text.fontColor = .white
        text.position = CGPoint(x: 250, y: 900)
        text.zPosition = MaskLevel.minusOne.rawValue
        pad.addChild(text)
        addChild(pad)
        teyTotalContour.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        teyTotalContour.alpha = 0
        
        
//        addChild(teyTotalContour)
    }
    
    private func setBlackNode() {
        teyTotalContour = SKSpriteNode(imageNamed: "TEY_total_contour")
        teyTigerWhite_pattern = SKSpriteNode(imageNamed: "TEY_0000_tiger_white_pattern")
        teyTigerContour = SKSpriteNode(imageNamed: "TEY_0001_tiger_contour")
        teyEar_in = SKSpriteNode(imageNamed: "TEY_0002_ear_in")
        teyTigerBeard = SKSpriteNode(imageNamed: "TEY_0003_tiger_beard")
        teyTigerEyeball = SKSpriteNode(imageNamed: "TEY_0004_tiger_eyeball")
        teyTigerEyewhite = SKSpriteNode(imageNamed: "TEY_0005_tiger_eyewhite")
        teyTigerNose = SKSpriteNode(imageNamed: "TEY_0006_tiger_nose")
        teyTigerMouth = SKSpriteNode(imageNamed: "TEY_0007_tiger_mouth")
        teyTigerLips = SKSpriteNode(imageNamed: "TEY_0008_tiger_lips")
        teyTigerLeg = SKSpriteNode(imageNamed: "TEY_0009_tiger_leg")
        teyTigerEarOut = SKSpriteNode(imageNamed: "TEY_0010_tiger_ear_out")
        teyPad = SKSpriteNode(imageNamed: "TEY_0011_pad")
        teyShoeDown = SKSpriteNode(imageNamed: "TEY_0012_shoe_down")
        teyShoe = SKSpriteNode(imageNamed: "TEY_0013_shoe")
        teyPants = SKSpriteNode(imageNamed: "TEY_0014_pants")
        teyClothMid = SKSpriteNode(imageNamed: "TEY_0015_cloth_mid")
        teyClothUp = SKSpriteNode(imageNamed: "TEY_0016_cloth_up")
        teyBeltPattern = SKSpriteNode(imageNamed: "TEY_0017_belt_pattern")
        teyBelt = SKSpriteNode(imageNamed: "TEY_0018_belt")
        teyLeftSleeve = SKSpriteNode(imageNamed: "TEY_0019_left_sleeve")
        teyHands = SKSpriteNode(imageNamed: "TEY_0020_hands")
        teyRightArmRing = SKSpriteNode(imageNamed: "TEY_0021_right_arm_ring")
        teyRightArm = SKSpriteNode(imageNamed: "TEY_0022_right_arm")
        teyMouth = SKSpriteNode(imageNamed: "TEY_0023_mouth")
        teyCheek = SKSpriteNode(imageNamed: "TEY_0024_cheek")
        teyEyes = SKSpriteNode(imageNamed: "TEY_0025_eyes")
        teyScarf = SKSpriteNode(imageNamed: "TEY_0026_scarf")
        teyHatDown = SKSpriteNode(imageNamed: "TEY_0027_hat_down")
        teyHatJew = SKSpriteNode(imageNamed: "TEY_0028_hat_jew")
        teyHatMid = SKSpriteNode(imageNamed: "TEY_0029_hat_mid")
        teyHatUp = SKSpriteNode(imageNamed: "TEY_0030_hat_up")
        teyRightEarIn = SKSpriteNode(imageNamed: "TEY_0031_right_ear_in")
        teyRightEar = SKSpriteNode(imageNamed: "TEY_0032_right_ear")
        teyLeftEarIn = SKSpriteNode(imageNamed: "TEY_0033_left_ear_in")
        teyLeftEar = SKSpriteNode(imageNamed: "TEY_0034_left_ear")
        teyFace = SKSpriteNode(imageNamed: "TEY_face")
        
        teyGold1 = SKSpriteNode(imageNamed:"teyGold1")
        teyGold2 = SKSpriteNode(imageNamed:"teyGold2")
        teyGold3 = SKSpriteNode(imageNamed:"teyGold3")
        teyGold4 = SKSpriteNode(imageNamed:"teyGold4")
        teyGold5 = SKSpriteNode(imageNamed:"teyGold5")
        teyGold6 = SKSpriteNode(imageNamed:"teyGold6")
        teyGold7 = SKSpriteNode(imageNamed:"teyGold7")
        teyGold8 = SKSpriteNode(imageNamed:"teyGold8")
        teyGold9 = SKSpriteNode(imageNamed:"teyGold9")
        teyGold10 = SKSpriteNode(imageNamed:"teyGold10")
        teyGold11 = SKSpriteNode(imageNamed:"teyGold11")
        teyGold12 = SKSpriteNode(imageNamed:"teyGold12")
        teyGold13 = SKSpriteNode(imageNamed:"teyGold13")
        teyGold14 = SKSpriteNode(imageNamed:"teyGold14")
        teyGold15 = SKSpriteNode(imageNamed:"teyGold15")
        teyGold16 = SKSpriteNode(imageNamed:"teyGold16")
        teyGold17 = SKSpriteNode(imageNamed:"teyGold17")
        teyGold18 = SKSpriteNode(imageNamed:"teyGold18")
        teyGold19 = SKSpriteNode(imageNamed:"teyGold19")
        teyGold20 = SKSpriteNode(imageNamed:"teyGold20")
        teyGold21 = SKSpriteNode(imageNamed:"teyGold21")
        teyGold22 = SKSpriteNode(imageNamed:"teyGold22")
        teyGold23 = SKSpriteNode(imageNamed:"teyGold23")
        teyGold24 = SKSpriteNode(imageNamed:"teyGold24")
        teyGold25 = SKSpriteNode(imageNamed:"teyGold25")
        teyGold26 = SKSpriteNode(imageNamed:"teyGold26")
        teyGold27 = SKSpriteNode(imageNamed:"teyGold27")
        teyGold28 = SKSpriteNode(imageNamed:"teyGold28")
        teyGold29 = SKSpriteNode(imageNamed:"teyGold29")
        teyGold30 = SKSpriteNode(imageNamed:"teyGold30")
        teyGold31 = SKSpriteNode(imageNamed:"teyGold31")
        teyGold32 = SKSpriteNode(imageNamed:"teyGold32")
        teyGold33 = SKSpriteNode(imageNamed:"teyGold33")
        teyGold34 = SKSpriteNode(imageNamed:"teyGold34")
        teyGold35 = SKSpriteNode(imageNamed:"teyGold35")
        teyGold36 = SKSpriteNode(imageNamed:"teyGold36")
        teyColor1 = SKSpriteNode(imageNamed:"teyColor1")
        teyColor2 = SKSpriteNode(imageNamed:"teyColor2")
        teyColor3 = SKSpriteNode(imageNamed:"teyColor3")
        teyColor4 = SKSpriteNode(imageNamed:"teyColor4")
        teyColor5 = SKSpriteNode(imageNamed:"teyColor5")
        teyColor6 = SKSpriteNode(imageNamed:"teyColor6")
        teyColor7 = SKSpriteNode(imageNamed:"teyColor7")
        teyColor8 = SKSpriteNode(imageNamed:"teyColor8")
        teyColor9 = SKSpriteNode(imageNamed:"teyColor9")
        teyColor10 = SKSpriteNode(imageNamed:"teyColor10")
        teyColor11 = SKSpriteNode(imageNamed:"teyColor11")
        teyColor12 = SKSpriteNode(imageNamed:"teyColor12")
        teyColor13 = SKSpriteNode(imageNamed:"teyColor13")
        teyColor14 = SKSpriteNode(imageNamed:"teyColor14")
        teyColor15 = SKSpriteNode(imageNamed:"teyColor15")
        teyColor16 = SKSpriteNode(imageNamed:"teyColor16")
        teyColor17 = SKSpriteNode(imageNamed:"teyColor17")
        teyColor18 = SKSpriteNode(imageNamed:"teyColor18")
        teyColor19 = SKSpriteNode(imageNamed:"teyColor19")
        teyColor20 = SKSpriteNode(imageNamed:"teyColor20")
        teyColor21 = SKSpriteNode(imageNamed:"teyColor21")
        teyColor22 = SKSpriteNode(imageNamed:"teyColor22")
        teyColor23 = SKSpriteNode(imageNamed:"teyColor23")
        teyColor24 = SKSpriteNode(imageNamed:"teyColor24")
        teyColor25 = SKSpriteNode(imageNamed:"teyColor25")
        teyColor26 = SKSpriteNode(imageNamed:"teyColor26")
        teyColor27 = SKSpriteNode(imageNamed:"teyColor27")
        teyColor28 = SKSpriteNode(imageNamed:"teyColor28")
        teyColor29 = SKSpriteNode(imageNamed:"teyColor29")
        teyColor30 = SKSpriteNode(imageNamed:"teyColor30")
        teyColor31 = SKSpriteNode(imageNamed:"teyColor31")
        teyColor32 = SKSpriteNode(imageNamed:"teyColor32")
        teyColor33 = SKSpriteNode(imageNamed:"teyColor33")
        teyColor34 = SKSpriteNode(imageNamed:"teyColor34")
        teyColor35 = SKSpriteNode(imageNamed:"teyColor35")
        teyColor36 = SKSpriteNode(imageNamed:"teyColor36")
        
        basicNodes = [teyTigerWhite_pattern, teyEar_in, teyTigerBeard, teyTigerEyeball, teyTigerEyewhite, teyTigerNose, teyTigerMouth, teyTigerLips, teyTigerLeg, teyTigerEarOut, teyTigerContour, teyShoeDown, teyShoe, teyPants,teyPad, teyClothMid, teyClothUp, teyBeltPattern, teyBelt, teyLeftSleeve, teyHands, teyRightArmRing, teyRightArm, teyMouth, teyCheek, teyEyes, teyScarf, teyHatDown, teyHatJew, teyHatMid, teyHatUp, teyRightEarIn, teyRightEar, teyLeftEarIn, teyLeftEar, teyFace]
        
        goldNodes = [teyGold1,teyGold2,teyGold3,teyGold4,teyGold5,teyGold6,teyGold7,teyGold8,teyGold9,teyGold10,teyGold11,teyGold12,teyGold13,teyGold14,teyGold15,teyGold16,teyGold17,teyGold18,teyGold19,teyGold20,teyGold21,teyGold22,teyGold23,teyGold24,teyGold25,teyGold26,teyGold27,teyGold28,teyGold29,teyGold30,teyGold31,teyGold32,teyGold33,teyGold34,teyGold35, teyGold36]
        colorNodes = [teyColor1,teyColor2,teyColor3,teyColor4,teyColor5,teyColor6,teyColor7,teyColor8,teyColor9,teyColor10,teyColor11,teyColor12,teyColor13,teyColor14,teyColor15,teyColor16,teyColor17,teyColor18,teyColor19,teyColor20,teyColor21,teyColor22,teyColor23,teyColor24,teyColor25,teyColor26,teyColor27,teyColor28,teyColor29,teyColor30,teyColor31,teyColor32,teyColor33,teyColor34,teyColor35, teyColor36]
        for eachNode in basicNodes {
            eachNode.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
            eachNode.alpha = 0.2
            eachNode.zPosition = (MaskLevel.minusOne).rawValue
            addChild(eachNode)
        }
        
        teyTigerContour.position = cgPointMake(toX: 490.5, toY: 629)
        teyTigerWhite_pattern.position = cgPointMake(toX: 499, toY: 606)
        teyEar_in.position = cgPointMake(toX: 264, toY: 520)
        teyTigerBeard.position = cgPointMake(toX: 274.5, toY: 676)
        teyTigerEyeball.position = cgPointMake(toX: 274.5, toY: 642)
        teyTigerEyewhite.position = cgPointMake(toX: 274, toY: 641.5)
        teyTigerNose.position = cgPointMake(toX: 263, toY: 669)
        teyTigerMouth.position = cgPointMake(toX: 274, toY: 715)
        teyTigerLips.position = cgPointMake(toX: 274, toY: 719.5)
        teyTigerLeg.position = cgPointMake(toX: 514.5, toY: 869.5)
        teyTigerEarOut.position = cgPointMake(toX: 263, toY: 518)
        teyPad.position = cgPointMake(toX: 554, toY: 811.5)
        teyShoeDown.position = cgPointMake(toX: 554.5, toY:806 )
        teyShoe.position = cgPointMake(toX: 554.5, toY: 794.5)
        teyPants.position = cgPointMake(toX: 550.5 , toY: 711.5)
        teyClothMid.position = cgPointMake(toX: 589, toY: 509.5)
        teyClothUp.position = cgPointMake(toX: 516.5, toY: 458.5)
        teyBeltPattern.position = cgPointMake(toX: 512, toY: 586.5)
        teyBelt.position = cgPointMake(toX: 519.5, toY: 595)
        teyLeftSleeve.position = cgPointMake(toX: 704.5, toY: 599.5)
        teyHands.position = cgPointMake(toX: 566, toY: 559.5)
        teyRightArmRing.position = cgPointMake(toX: 471.5, toY: 531.5)
        teyRightArm.position = cgPointMake(toX: 412.5, toY: 472.5)
        teyMouth.position = cgPointMake(toX: 540, toY: 387)
        teyCheek.position = cgPointMake(toX: 541, toY: 365)
        teyEyes.position = cgPointMake(toX: 537.5, toY: 323.5)
        teyScarf.position = cgPointMake(toX: 537.5, toY: 425.5)
        teyHatDown.position = cgPointMake(toX: 541.5, toY: 286)
        teyHatJew.position = cgPointMake(toX: 541, toY: 214.5)
        teyHatMid.position = cgPointMake(toX: 541, toY: 369.5)
        teyHatUp.position = cgPointMake(toX: 541.5, toY: 224.5)
        teyRightEarIn.position = cgPointMake(toX: 628.5, toY: 145.5)
        teyRightEar.position = cgPointMake(toX: 611, toY: 148.5)
        teyLeftEarIn.position = cgPointMake(toX: 455, toY: 146)
        teyLeftEar.position = cgPointMake(toX: 472, toY: 149.5)
        teyFace.position = cgPointMake(toX: 541, toY: 342)
        
        teyMouth.zPosition = MaskLevel.minusOneUp.rawValue
        teyTigerWhite_pattern.zPosition = MaskLevel.minusOneUp.rawValue
        teyTigerEarOut.zPosition = (MaskLevel.minusOneUp).rawValue
        teyBeltPattern.zPosition = MaskLevel.minusOneUp.rawValue
        
        for index in 0..<colorNodes.count {
            colorNodes[index].position = basicNodes[index].position
            colorNodes[index].zPosition = (MaskLevel.zero).rawValue
            colorNodes[index].alpha = 0.1
            addChild(colorNodes[index])
        }
        for index in 0..<goldNodes.count {
            goldNodes[index].position = CGPoint(x: 250, y: 800)
            goldNodes[index].isHidden = true
            goldNodes[index].setScale(0.3)
            addChild(goldNodes[index])
            goldNodes[index].zPosition = (MaskLevel.one).rawValue
        }
        goldNodes[0].isHidden = false
        
        teyGold1.zPosition = MaskLevel.zeroUp.rawValue
        teyGold2.zPosition = MaskLevel.zeroUp.rawValue
        teyGold3.zPosition = MaskLevel.zeroUp.rawValue
        teyGold4.zPosition = MaskLevel.zeroUp.rawValue
        teyGold5.zPosition = MaskLevel.zeroUp.rawValue
        teyGold6.zPosition = MaskLevel.zeroUp.rawValue
        teyGold7.zPosition = MaskLevel.zeroUp.rawValue
        teyGold8.zPosition = MaskLevel.zeroUp.rawValue
        teyGold9.zPosition = MaskLevel.zeroUp.rawValue
        teyGold10.zPosition = MaskLevel.zeroUp.rawValue
        teyGold12.zPosition = MaskLevel.zeroUp.rawValue
        teyGold13.zPosition = MaskLevel.zeroUp.rawValue
        teyGold18.zPosition = MaskLevel.zeroUp.rawValue
        teyGold24.zPosition = MaskLevel.zeroUp.rawValue
        teyGold25.zPosition = MaskLevel.zeroUp.rawValue
        teyGold26.zPosition = MaskLevel.zeroUp.rawValue
        teyColor1.zPosition = MaskLevel.oneUp.rawValue
        teyColor2.zPosition = MaskLevel.oneUp.rawValue
        teyColor3.zPosition = MaskLevel.oneUp.rawValue
        teyColor4.zPosition = MaskLevel.oneUp.rawValue
        teyColor5.zPosition = MaskLevel.oneUp.rawValue
        teyColor6.zPosition = MaskLevel.oneUp.rawValue
        teyColor7.zPosition = MaskLevel.oneUp.rawValue + 0.1
        teyColor8.zPosition = MaskLevel.oneUp.rawValue
        teyColor9.zPosition = MaskLevel.oneUp.rawValue
        teyColor10.zPosition = MaskLevel.oneUp.rawValue
        teyColor12.zPosition = MaskLevel.oneUp.rawValue
        teyColor13.zPosition = MaskLevel.oneUp.rawValue
        teyColor18.zPosition = MaskLevel.oneUp.rawValue
        teyColor24.zPosition = MaskLevel.oneUp.rawValue
        teyColor25.zPosition = MaskLevel.oneUp.rawValue
        teyColor26.zPosition = MaskLevel.oneUp.rawValue
    }
    
    func cgPointMake(toX: CGFloat, toY: CGFloat) -> CGPoint {
        return CGPoint(x: toX, y: Resolution.height - toY)
    }
    
    func showGold() {
        
    }
    
    func showColor() {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if colorEnd {
            let textbar = SKLabelNode(text: "Finish")
            textbar.fontColor = .black
            textbar.position = CGPoint(x: 500, y: 900)
            addChild(textbar)
        }
        let position = (touches.first?.location(in: self))
//        print(position!)
        guard position != nil else {
            return
        }
        let nodes = self.nodes(at: position!) as! [SKSpriteNode]
        if !colorBegin {
            goldNodes[currentGold].setScale(1)
        } else {
            for nowNode in nodes {
//                if nowNode.name != nil && nowNode.name == "color" {
                print(nowNode.alpha)
                if nowNode.alpha < 0.2  {
                    let moveAction = SKAction.fadeAlpha(to: 1, duration: 1)
                    nowNode.run(SKAction.sequence([ moveAction]))
                        colorCount += 1
                    }
                    if colorCount >= 36 {
                        colorEnd = true
                        pad.removeFromParent()
                        break
                    }
//                }
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let position = touches.first?.location(in: self)
        guard position != nil else {
            return
        }
        if !colorBegin {
            goldNodes[currentGold].position = position!
        } else {
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if colorBegin {
            return
        }
        let position = touches.first?.location(in:self)
        guard position != nil else {
            return
        }
        if CGPointDistance(from: position!, to: basicNodes[currentGold].position) <= 50 {
            goldNodes[currentGold].position = basicNodes[currentGold].position
            basicNodes[currentGold].isHidden = true
            currentGold += 1
            if currentGold < 36 {
                goldNodes[currentGold].isHidden = false
            } else {
                colorBegin = true
                pad.removeFromParent()
            }
        } else {
            goldNodes[currentGold].position = CGPoint(x: 250, y: 800)
            goldNodes[currentGold].setScale(0.3)
        }
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    func CGPointDistance(from: CGPoint, to: CGPoint) -> CGFloat {
        return sqrt(CGPointDistanceSquared(from: from, to: to))
    }
    func CGPointDistanceSquared(from: CGPoint, to: CGPoint) -> CGFloat {
        return (from.x - to.x) * (from.x - to.x) + (from.y - to.y) * (from.y - to.y)
    }
}

enum MaskLevel: CGFloat {
    case minusOne = -1
    case minusOneUp = -0.9
    case zero = 0
    case zeroUp = 0.1
    case one = 1
    case oneUp = 1.1
}

